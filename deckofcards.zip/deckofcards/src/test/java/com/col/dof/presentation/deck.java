package com.col.dof.presentation;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class deck 
{
	String deckID = null;
	
	RequestSpecBuilder reqSpecBuilder;
	ResponseSpecBuilder resSpecBuilder;
	
	static RequestSpecification reqSpec;
	static ResponseSpecification resSpec;
	
	@BeforeClass
	public void setup()
	{
		reqSpecBuilder = new RequestSpecBuilder();
		reqSpecBuilder.setBaseUri("http://deckofcardsapi.com");
		reqSpecBuilder.setBasePath("/api/deck");
		reqSpecBuilder.addHeader("Content-Type","application/json");
		reqSpec = reqSpecBuilder.build();
		
		resSpecBuilder = new ResponseSpecBuilder();
		resSpecBuilder.expectStatusCode(200);
		resSpec = resSpecBuilder.build();
	}

	@Test(enabled=true)
	public void NewDeck()
	{
			Response res = 
				given()
				    .spec(reqSpec)
					.queryParam("jokers_enabled", true)
				.when()
					.get("/new/")
				.then()
					.statusCode(200)
					.extract().response();
						
			JsonPath js = new JsonPath(res.asString());
			Assert.assertEquals(js.getString("remaining"), "54");
			Assert.assertTrue(js.getString("deck_id")!=null);

			deckID = js.getString("deck_id");
			
			res = 
					given()
				    	.spec(reqSpec)
					.when()
						.get("/"+deckID+"/draw")
					.then()
						.spec(resSpec)
						.extract().response();
			
			js = new JsonPath(res.asString());
			
			System.out.println(res.body().prettyPrint());
			Assert.assertEquals(js.getString("remaining"), "53");
			Assert.assertTrue(js.getString("cards.value") != null);
			Assert.assertTrue(js.getString("cards.suit")!=null);
			Assert.assertTrue(js.getString("cards.images.svg")!=null);
			Assert.assertTrue(js.getString("cards.images.png")!=null);	
	}
}
